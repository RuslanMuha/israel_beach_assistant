---
name: test-design
description: Design or review Java/Spring tests with correct scope, profile isolation, realistic dependencies, and honest verification reporting.
---

# Test Design

## When to Use
- Design tests for a new feature or milestone.
- Review whether existing tests use the right slice, profile, and dependency strategy.
- Decide between unit, slice, integration, Testcontainers, local test adapters, and mocks.

## When NOT to Use
- Pure production code implementation with no test design question.
- Performance/load testing plans.
- Broad architecture design not centered on verification strategy.

## Required Input
- Target behavior to verify.
- Infrastructure involved: DB, HTTP, storage, messaging, cloud services.
- Available profiles/testcontainers/stubs if known.

## Workflow
1. Choose the narrowest test type that can verify the target behavior.
2. Decide which dependencies should be real, containerized, local-safe, fake, or mocked.
3. If wiring differs from production, use a dedicated test profile.
4. Keep test-only infrastructure out of production configuration.
5. Remove mocks that do not affect the asserted behavior.
6. Report exactly what was verified, skipped by design, or blocked by the environment.

## Output Contract
Return:
1. `Test Scope`
2. `Dependency Strategy`
3. `Profiles / Wiring`
4. `Required Tests`
5. `Verification Notes`

## Guardrails
- Do not add skip/disable annotations merely to bypass missing local prerequisites.
- If a prerequisite such as Docker is unavailable, report the blocked verification honestly.
- Only use skip conditions that are part of the intended long-term test design.
- Do not mix visibility styles in one test class without a concrete reason.
